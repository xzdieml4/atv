const chamadoServices = require('../services/chamadoServices');

const listarChamados = (req, res) => {
    try {
        const chamados = chamadoServices.obterTodosChamados();
        return res.status(200).json(chamados);
    } catch (error) {
        return res.status(500).json({ mensagem: 'Erro interno ao listar chamados.', erro: error.message });
    }
};

const criarChamado = (req, res) => {
    try {
        const { titulo, prioridade } = req.body;

        if (!titulo || !prioridade) {
            return res.status(400).json({ mensagem: 'Os campos "titulo" e "prioridade" são obrigatórios.' });
        }

        const novoChamado = chamadoServices.cadastrarChamado({ titulo, prioridade });
        return res.status(201).json({ mensagem: 'Chamado criado com sucesso!', chamado: novoChamado });
    } catch (error) {
        return res.status(500).json({ mensagem: 'Erro interno ao criar chamado.', erro: error.message });
    }
};

module.exports = {
    listarChamados,
    criarChamado
};