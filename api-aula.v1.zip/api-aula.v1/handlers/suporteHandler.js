function suporteN1(chamado){
    console.log("N1 revebeu chamado");
    if(chamado.prioridade === "normal"){
        console.log("N1 assumiu o chamado");
        return "Suporte N1 atendeu o chamado";
    }
    console,log("N1 não conseguiu resolver");
    console.log("Encaminhado para N2");
    return suporteN2(chamado);
}

function suporteN2(chamado){
    console.log("N2 revebeu chamado");
    if(chamado.prioridade === "media"){
        console.log("N2 assumiu o chamado");
        return "Suporte N2 atendeu o chamado";
    }
    console,log("N2 não conseguiu resolver");
    console.log("Encaminhado para N2");
    return suporteN2(chamado);
}
function especcialista(chamado){
    console.log("ESPECIALISTA revebeu chamado");
    if(chamado.prioridade === "alta"){
        console.log("ESPECIALISTA assumiu o chamado");
        return "Suporte ESPECIALISTA atendeu o chamado";
    }
    throw new Error("Nenhum responsável encontrado");
}

module.exports = {
    suporteN1
}