const express = require('express');
const chamadoRoutes = require('./routes/chamadoRoutes');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware para processar requisições em formato JSON
app.use(express.json());

// Rotas da aplicação
app.use('/chamados', chamadoRoutes);

app.listen(PORT, () => {
    console.log(`Servidor rodando com sucesso na porta ${PORT}`);
});