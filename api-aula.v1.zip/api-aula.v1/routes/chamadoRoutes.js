const express = require('express');
const router = express.Router();
const chamadoController = require('../controllers/chamadoController');

router.get('/', chamadoController.listarChamados);
router.post('/', chamadoController.criarChamado);

module.exports = router;