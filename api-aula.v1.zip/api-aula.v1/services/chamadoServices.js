const suporteHandler = require('../handlers/suporteHandler');

// Simulador de base de dados em memória
const chamados = [
    { id: 1, titulo: 'Impressora não funciona', prioridade: 'alta', status: 'aberto' }
];

const obterTodosChamados = () => {
    return chamados;
};

const cadastrarChamado = (dadosChamado) => {
    const novoChamado = {
        id: chamados.length + 1,
        titulo: dadosChamado.titulo,
        prioridade: dadosChamado.prioridade,
        status: 'aberto',
        dataCriacao: new Date().toISOString()
    };

    chamados.push(novoChamado);
    suporteHandler.notificarNovoChamado(novoChamado);

    return novoChamado;
};

module.exports = {
    obterTodosChamados,
    cadastrarChamado
};